import React, { Component } from 'react';
import '../css/Header.css';

class Header extends Component {
  render() {
    return (
      <header className="header">
        Title
      </header>
    );
  }
}

export default Header;
